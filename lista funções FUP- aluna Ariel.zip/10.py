from math import pi
def funcao(grau):
    rad = grau*pi/180
    return rad
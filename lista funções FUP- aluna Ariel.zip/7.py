def funcao(num):
    return num ** 2
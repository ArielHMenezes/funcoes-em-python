from math import pi
def funcao(raio):
    vol = 4/3 * pi * raio ** 3
    area = 4 * pi * raio ** 2
    return vol, area
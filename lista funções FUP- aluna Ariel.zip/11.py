def funcao(x1, x2, x3):
    soma_dos_quadrados = (x1 ** 2) + (x2 ** 2) + (x3 ** 2)
    quadrado_da_soma = (x1 + x2 + x3) ** 2
    return soma_dos_quadrados, quadrado_da_soma
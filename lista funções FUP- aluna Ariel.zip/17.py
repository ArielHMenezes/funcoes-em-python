from math import sqrt
def funcao(x, y):
    distancia = sqrt(x ** 2 + y ** 2)
    return distancia
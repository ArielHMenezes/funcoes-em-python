def funcao(C):
    F = C * (9.0/5.0) + 32.
    return F
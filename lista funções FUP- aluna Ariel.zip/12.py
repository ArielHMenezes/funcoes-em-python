def funcao(salario):
    return salario + ((salario/100) * 21.37)
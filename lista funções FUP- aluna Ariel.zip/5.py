def funcao(lado):
    return lado**2
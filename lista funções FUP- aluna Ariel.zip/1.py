def funcao(x):
    return x*2

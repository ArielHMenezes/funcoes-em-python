def funcao(reais):
    cambio = 5.27
    return reais*cambio
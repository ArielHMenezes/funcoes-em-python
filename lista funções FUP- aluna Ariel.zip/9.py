def funcao(kh):
    ms = kh/3.6
    return ms
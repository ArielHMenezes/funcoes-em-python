def funcao(num):
    return num-1,num+1
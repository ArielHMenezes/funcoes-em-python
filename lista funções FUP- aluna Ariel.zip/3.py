def funcao(l1,l2):
    area = l1 * l2
    perimetro = 2 * (l1+l2)
    return area, perimetro
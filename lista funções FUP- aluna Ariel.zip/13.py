def funcao(valor):
    ganhador1 = (valor/100)*46
    ganhador2 = (valor/100)*32
    ganhador3 = valor-(ganhador1+ganhador2)
    return ganhador1, ganhador2, ganhador3